#!/usr/bin/env bash
set -euo pipefail

echo "[*] Saved config:"
